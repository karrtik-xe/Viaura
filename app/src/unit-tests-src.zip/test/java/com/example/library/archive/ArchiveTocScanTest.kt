package com.example.util.archive

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ArchiveTocScanTest {

    private class BytesSource(private val data: ByteArray) : ArchiveSource {
        override fun length(): Long = data.size.toLong()
        override fun open(offset: Long, length: Long): InputStream {
            val from = offset.toInt()
            val to = minOf(data.size.toLong(), offset + length).toInt()
            return ByteArrayInputStream(data, from, to - from)
        }
    }

    private fun sampleBytes(size: Int, seed: Int): ByteArray = ByteArray(size) { ((it * 31 + seed) % 251).toByte() }

    private fun buildZip(files: List<Triple<String, ByteArray, Boolean>>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            for ((name, bytes, stored) in files) {
                val entry = ZipEntry(name)
                if (stored) {
                    entry.method = ZipEntry.STORED
                    entry.size = bytes.size.toLong()
                    entry.compressedSize = bytes.size.toLong()
                    entry.crc = CRC32().also { it.update(bytes) }.value
                }
                zip.putNextEntry(entry)
                zip.write(bytes)
                zip.closeEntry()
            }
        }
        return out.toByteArray()
    }

    @Test
    fun zipListsFilesAndReadsStoredAndDeflatedRanges() {
        val a = sampleBytes(70_000, 1)
        val b = sampleBytes(40_000, 2)
        val zip = buildZip(
            listOf(
                Triple("Show/Episode 01.mkv", a, true),
                Triple("Show/Episode 02.mp4", b, false),
                Triple("Show/readme.txt", "hi".toByteArray(), false)
            )
        )
        val source = BytesSource(zip)
        val scan = ArchiveEngine.scan(source, "show.zip")
        assertEquals(ArchiveKind.ZIP, scan.kind)
        assertEquals(3, scan.entries.size)

        val videos = scan.entries.filter { ArchiveEngine.isVideoName(it.name) }
        assertEquals(2, videos.size)

        for ((entry, expected) in listOf(videos[0] to a, videos[1] to b)) {
            val dataOffset = ArchiveEngine.resolveZipDataOffset(source, entry)
            val whole = ArchiveEngine.openEntry(source, ArchiveKind.ZIP, entry, dataOffset, 0L).use { it.readBytes() }
            assertArrayEquals(expected, whole)
            val tail = ArchiveEngine.openEntry(source, ArchiveKind.ZIP, entry, dataOffset, 12_345L).use { it.readBytes() }
            assertArrayEquals(expected.copyOfRange(12_345, expected.size), tail)
        }
    }

    @Test
    fun tarListsFilesAndReadsRanges() {
        val a = sampleBytes(1_300, 3)
        val b = sampleBytes(9_000, 4)
        val tar = ByteArrayOutputStream()
        fun add(name: String, bytes: ByteArray) {
            val header = ByteArray(512)
            name.toByteArray().copyInto(header)
            String.format("%07o", bytes.size).toByteArray().copyInto(header, 124)
            header[135] = 0
            header[156] = '0'.code.toByte()
            "ustar".toByteArray().copyInto(header, 257)
            for (i in 148 until 156) header[i] = ' '.code.toByte()
            val sum = header.sumOf { it.toInt() and 0xFF }
            String.format("%06o", sum).toByteArray().copyInto(header, 148)
            header[154] = 0
            header[155] = ' '.code.toByte()
            tar.write(header)
            tar.write(bytes)
            tar.write(ByteArray(((bytes.size + 511) / 512) * 512 - bytes.size))
        }
        add("d/ep1.mkv", a)
        add("d/ep2.mp4", b)
        tar.write(ByteArray(1024))

        val source = BytesSource(tar.toByteArray())
        val scan = ArchiveEngine.scan(source, "show.tar")
        assertEquals(ArchiveKind.TAR, scan.kind)
        assertEquals(listOf("d/ep1.mkv", "d/ep2.mp4"), scan.entries.map { it.name })
        val second = scan.entries[1]
        val tail = ArchiveEngine.openEntry(source, ArchiveKind.TAR, second, second.dataOffset, 100L).use { it.readBytes() }
        assertArrayEquals(b.copyOfRange(100, b.size), tail)
    }

    @Test
    fun videoNamesAreRecognised() {
        assertTrue(ArchiveEngine.isVideoName("a/b/Episode 01.MKV"))
        assertFalse(ArchiveEngine.isVideoName("a/b/subs.srt"))
    }
}
