package com.example.util

import org.junit.Assert.assertEquals
import org.junit.Test

class EpisodeNumberParsingTest {

    private fun p(name: String) = EpisodeNameParser.parse(name)

    @Test
    fun sxeStyles() {
        assertEquals(14 to 5, p("[AniDL] Bleach S14E05 [1080p][ABCD1234]").let { it.season to it.episode })
        assertEquals("Bleach", p("[AniDL] Bleach S14E05 [1080p][ABCD1234]").title)
        assertEquals(1 to 2, p("Breaking.Bad.S01E02.720p.BluRay.x264-DEMAND").let { it.season to it.episode })
        assertEquals(1 to 12, p("Show Name 1x12 Title").let { it.season to it.episode })
        assertEquals(2 to 7, p("Show Name Season 2 Episode 7").let { it.season to it.episode })
    }

    @Test
    fun fansubStyles() {
        assertEquals(14 to 5, p("[AniDL] Bleach S14 - 05 [1080p x265]").let { it.season to it.episode })
        assertEquals(3, p("[Erai-raws] Mob Psycho 100 - 03 [1080p]").episode)
        assertEquals(25, p("Attack on Titan - 25v2 [720p]").episode)
        assertEquals(5, p("86 - 05 [1080p]").episode)
    }

    @Test
    fun noEpisode() {
        assertEquals(null, p("Movie Night 2019 1080p").episode)
    }

    @Test
    fun sequenceKeepsOrderNumbers() {
        val items = listOf(
            BulkRenameItem("/d/a.mkv", "/d", "a.mkv"),
            BulkRenameItem("/d/b.mkv", "/d", "b.mkv")
        )
        val r = BulkRenameEngine.compute(items, BulkRenameConfig(pattern = "File_", startNumber = 1, padding = 2))
        assertEquals("File_01.mkv", r[0].newName)
        assertEquals("File_02.mkv", r[1].newName)
    }
}
