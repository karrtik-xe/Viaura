package com.example.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NextTrackOrderTest {

    private fun t(i: Int, artist: String, title: String = "song $i") =
        OnlineTrackResult(videoUrl = "u$i", title = title, artist = artist, durationSec = 200L, thumbnailUrl = null)

    private val seed = OnlineTrackSequencer.creatorKey("Arijit Singh")

    @Test
    fun creatorKeyIgnoresTopicVevoAndOfficial() {
        assertEquals("arijit singh", OnlineTrackSequencer.creatorKey("Arijit Singh - Topic"))
        assertEquals(OnlineTrackSequencer.creatorKey("ArijitSinghVEVO").replace(" ", ""), "arijitsingh")
    }

    @Test
    fun nextTrackIsNeverBySameArtistAndNoTwoInARow() {
        val items = listOf(
            t(1, "Arijit Singh - Topic"), t(2, "T-Series"), t(3, "Arijit Singh"), t(4, "T-Series"),
            t(5, "Sony Music"), t(6, "Zee Music"), t(7, "Sony Music"), t(8, "Tips")
        )
        val out = OnlineTrackSequencer.arrange(items, seed, "cur")
        assertFalse(OnlineTrackSequencer.isSameCreator(seed, out.first()))
        for (i in 1 until out.size) assertTrue(out[i].artist != out[i - 1].artist)
    }

    @Test
    fun playingArtistComesBackAfterThreeOthers() {
        val others = (1..6).map { t(it, "Artist $it") }
        val extras = listOf(t(50, "Lofi Edits", "Kesariya slowed (Arijit Singh)"))
        val out = OnlineTrackSequencer.arrange(others, seed, "cur", extras)
        assertEquals("u50", out[3].videoUrl)
    }

    @Test
    fun currentTrackAndDuplicatesAreDropped() {
        val out = OnlineTrackSequencer.arrange(listOf(t(1, "A"), t(1, "A"), t(2, "B")), seed, "u2")
        assertEquals(listOf("u1"), out.map { it.videoUrl })
    }

    @Test
    fun preferredKindComesFirst() {
        val items = listOf(t(1, "A", "cooking pasta"), t(2, "B", "cricket match"), t(3, "C", "cricket highlights"))
        val out = OnlineTrackSequencer.arrange(items, "x", "cur", preferred = { it.title.contains("cricket") })
        assertEquals(listOf("u2", "u3", "u1"), out.map { it.videoUrl })
    }
}
