package com.example.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ViewerInterestLearningTest {

    @Test
    fun extractTopics_recognisesKnownGameAndItsCategory() {
        val topics = OnlineInterestProfile.extractTopics("I Survived 100 Days in Minecraft Hardcore!")
        assertEquals("minecraft", topics.first().name)
        assertEquals("gaming", topics.first().category)
    }

    @Test
    fun extractTopics_fallsBackToSignificantWords() {
        val topics = OnlineInterestProfile.extractTopics("Official Video - Zebra Migration Documentary")
        assertEquals(1, topics.size)
        assertEquals("zebra migration", topics.first().name)
    }

    @Test
    fun extractTopics_doesNotMatchInsideOtherWords() {
        assertTrue(OnlineInterestProfile.extractTopics("sagta kaam").none { it.name == "gta 5" })
    }

    @Test
    fun relatedTopics_ofMinecraftAreOtherGames() {
        val related = OnlineInterestProfile.relatedTopics("minecraft")
        assertTrue("terraria" in related)
        assertFalse("minecraft" in related)
    }

    @Test
    fun videoQueryFor_addsGameplayOnlyForGames() {
        assertEquals("minecraft gameplay", OnlineInterestProfile.videoQueryFor("minecraft"))
        assertEquals("cricket", OnlineInterestProfile.videoQueryFor("cricket"))
    }

    @Test
    fun diverseQueries_neverUseTheCategoryTheUserIsIn() {
        val q = OnlineInterestProfile.diverseQueries(
            OnlineInterestProfile.KIND_VIDEO, setOf("tech"), 3
        ) { it.first() }
        assertEquals(3, q.size)
        assertFalse(q.any { it.contains("tech review") || it.contains("smartphone") })
    }

    @Test
    fun extractTopics_recognisesMusicTastes() {
        assertEquals("punjabi songs", OnlineInterestProfile.extractTopics("Brown Munde AP Dhillon").first().name)
        assertEquals("phonk", OnlineInterestProfile.extractTopics("Drift phonk mix").first().category)
        assertEquals("retro", OnlineInterestProfile.extractTopics("Kishore Kumar purane gaane").first().category)
    }

    @Test
    fun extractTopics_canSkipLooseWordsForSongs() {
        assertTrue(OnlineInterestProfile.extractTopics("Some Random Title", allowWords = false).isEmpty())
    }

    @Test
    fun audioPopularGroups_startWithTheListenersOwnLanguageThenRapThenHindi() {
        val groups = OnlineInterestProfile.audioPopularGroups(listOf("punjabi songs"))
        assertEquals(3, groups.size)
        assertTrue(groups.first().any { it.contains("punjabi") })
        assertTrue(groups[1].any { it.contains("rap") })
        assertTrue(groups[2].any { it.contains("hindi") || it.contains("bollywood") })
    }
}
