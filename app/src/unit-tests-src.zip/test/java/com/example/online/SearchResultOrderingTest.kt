package com.example.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchResultOrderingTest {

    private fun track(title: String, channel: String, views: Long, durationSec: Long = 240L) = OnlineTrackResult(
        videoUrl = "https://www.youtube.com/watch?v=${title.hashCode()}",
        title = title,
        artist = channel,
        durationSec = durationSec,
        thumbnailUrl = null,
        viewCount = views
    )

    @Test
    fun originalUploadComesBeforeCoversAndSlowedVersions() {
        val items = listOf(
            track("Kesariya (Cover) by Some Singer", "Some Singer", 5_000_000L),
            track("Kesariya slowed reverb", "Lofi Edits", 20_000_000L),
            track("Kesariya - Brahmastra | Official Video", "Sony Music India", 400_000_000L)
        )
        val ranked = OnlineSearchRanker.rank("kesariya", items)
        assertEquals("Kesariya - Brahmastra | Official Video", ranked.first().title)
    }

    @Test
    fun aWordTheUserTypedIsNotPenalised() {
        val items = listOf(
            track("Brown Munde official video", "AP Dhillon", 300_000_000L),
            track("Brown Munde slowed reverb", "Lofi Edits", 10_000_000L)
        )
        val ranked = OnlineSearchRanker.rank("brown munde slowed reverb", items)
        assertEquals("Brown Munde slowed reverb", ranked.first().title)
    }

    @Test
    fun clipsAreNotOnTop() {
        val items = listOf(
            track("Believer", "Random Clip", 90_000_000L, durationSec = 20L),
            track("Believer - Imagine Dragons", "ImagineDragonsVEVO", 2_000_000_000L)
        )
        assertEquals("ImagineDragonsVEVO", OnlineSearchRanker.rank("believer", items).first().artist)
    }

    @Test
    fun equalResultsKeepYouTubesOrder() {
        val items = listOf(track("Some Topic A", "Chan A", 1000L), track("Some Topic B", "Chan B", 1000L))
        assertEquals(items.map { it.title }, OnlineSearchRanker.rank("some topic", items).map { it.title })
    }

    @Test
    fun onlyChannelsThatMatchTheQueryStayAsCards() {
        val channels = listOf(
            OnlineChannelResult("u1", "Arijit Singh", null, null, null),
            OnlineChannelResult("u2", "Random Vlogs", null, null, null)
        )
        val kept = OnlineSearchRanker.relevantChannels("arijit singh", channels)
        assertEquals(listOf("Arijit Singh"), kept.map { it.name })
        assertTrue(OnlineSearchRanker.relevantChannels("kesariya", channels).isEmpty())
    }
}
