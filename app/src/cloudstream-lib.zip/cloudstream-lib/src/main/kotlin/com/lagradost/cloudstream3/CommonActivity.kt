package com.lagradost.cloudstream3

import android.app.Activity
import android.widget.Toast
import com.lagradost.cloudstream3.utils.Coroutines.runOnMainThread
import java.lang.ref.WeakReference

/**
 * Stand-in for CloudStream's `CommonActivity`.
 *
 * Current CloudStream declares it as `object CommonActivity`, so an extension compiled against it reads the static field
 * `CommonActivity.INSTANCE` and calls the member functions on it. A plain class + companion has no such field, which made
 * every call fail with "No field INSTANCE of type Lcom/lagradost/cloudstream3/CommonActivity;" (e.g. the manga chapter
 * error). The class therefore exposes [INSTANCE] and the same member functions; the companion members stay for older
 * extensions that go through `CommonActivity.Companion`.
 */
class CommonActivity {
    var activity: Activity?
        get() = Companion.activity
        set(value) {
            Companion.activity = value
        }

    fun showToast(message: String?, duration: Int? = null) = Companion.showToast(message, duration)

    fun showToast(message: Int, duration: Int? = null) = Companion.showToast(message, duration)

    fun showToast(activity: Activity?, message: String?, duration: Int? = null) =
        Companion.showToast(activity, message, duration)

    fun showToast(activity: Activity?, message: Int, duration: Int? = null) =
        Companion.showToast(activity, message, duration)

    companion object {
        @JvmField
        val INSTANCE: CommonActivity = CommonActivity()

        private var _activity: WeakReference<Activity>? = null
        var activity: Activity?
            get() = _activity?.get()
            set(value) {
                _activity = value?.let { WeakReference(it) }
            }

        fun showToast(message: String?, duration: Int? = null) {
            if (message == null) return
            val ctx = CloudStreamApp.context ?: return
            runOnMainThread {
                try {
                    Toast.makeText(ctx, message, duration ?: Toast.LENGTH_SHORT).show()
                } catch (_: Throwable) {
                }
            }
        }

        fun showToast(message: Int, duration: Int? = null) {
            val text = try {
                CloudStreamApp.context?.getString(message)
            } catch (_: Throwable) {
                null
            }
            showToast(text, duration)
        }

        fun showToast(activity: Activity?, message: String?, duration: Int? = null) = showToast(message, duration)

        fun showToast(activity: Activity?, message: Int, duration: Int? = null) = showToast(message, duration)
    }
}
