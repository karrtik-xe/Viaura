package com.lagradost.cloudstream3.network

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.lagradost.cloudstream3.CloudStreamApp
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Counters shared by every code path that puts a WebView in front of the user (see [BrowserChallenge], [WebViewResolver]). */
object InAppBrowserGate {
    /** In-app browsers on screen right now. A provider call does not run into its time limit while the user is busy in one. */
    val open = AtomicInteger(0)

    /** [WebViewResolver] runs that are alive; their own sub-requests must not start a second browser. */
    val resolvers = AtomicInteger(0)
}

/**
 * Vega-like browser check for CloudStream extensions.
 *
 * Every request of a provider goes through [BrowserChallengeInterceptor]. When the site answers with a Cloudflare / DDoS-Guard
 * "Just a moment / verify you are human" page or a login wall, the same page is opened in the in-app browser
 * ([WebViewResolver.showBrowser]), the user passes the check or signs in and taps Done, and the request is repeated with the
 * cookies of that browser session (and its user agent). Later requests to the site keep sending them.
 */
object BrowserChallenge {
    enum class Kind { AUTO, MANUAL }

    private const val AUTO_SHOW_DELAY_MS = 2_500L
    private const val AUTO_TIMEOUT_MS = 60_000L
    private const val MANUAL_TIMEOUT_MS = 300_000L
    private const val CANCEL_COOLDOWN_MS = 120_000L
    private const val BLOCKED_COOLDOWN_MS = 300_000L
    private val CHALLENGE_TITLES = listOf(
        "just a moment", "attention required", "checking your browser", "verifying", "one more step", "security check", "ddos-guard"
    )
    private val CF_MARKERS = listOf(
        "just a moment", "cf-chl", "challenge-platform", "attention required", "checking your browser", "turnstile", "verify you are human"
    )
    private val OTHER_MARKERS = listOf("ddos-guard", "verify you are human", "g-recaptcha", "hcaptcha", "are you a robot", "security check")
    private val LOGIN_MARKERS = listOf("login", "log in", "sign in", "signin")

    private val sessionHosts = ConcurrentHashMap.newKeySet<String>()
    private val savedTried = ConcurrentHashMap.newKeySet<String>()
    private val locks = ConcurrentHashMap<String, Mutex>()
    private val doneAt = ConcurrentHashMap<String, Long>()
    private val cooldownUntil = ConcurrentHashMap<String, Long>()

    private fun webCookies(url: String): String =
        try { CookieManager.getInstance().getCookie(url) ?: "" } catch (_: Throwable) { "" }

    private fun cookieValue(header: String, name: String): String? {
        for (part in header.split(';')) {
            val eq = part.indexOf('=')
            if (eq > 0 && part.substring(0, eq).trim() == name) return part.substring(eq + 1).trim()
        }
        return null
    }

    private fun cookieMap(header: String, into: MutableMap<String, String>) {
        for (part in header.split(';')) {
            val eq = part.indexOf('=')
            if (eq > 0) into[part.substring(0, eq).trim()] = part.substring(eq + 1).trim()
        }
    }

    /** Cookie + User-Agent of the browser session of this site (empty when the user never passed a check there). */
    fun sessionHeaders(url: String): Map<String, String> {
        val host = try { java.net.URI(url).host } catch (_: Throwable) { null } ?: return emptyMap()
        if (!sessionHosts.contains(host)) return emptyMap()
        val out = LinkedHashMap<String, String>()
        val cookies = webCookies(url)
        if (cookies.isNotBlank()) out["Cookie"] = cookies
        val ua = try { WebViewResolver.getWebViewUserAgent() } catch (_: Throwable) { null }
        if (!ua.isNullOrBlank()) out["User-Agent"] = ua
        return out
    }

    /** [request] with the browser session of its site (cookies merged into the provider's own, browser user agent). */
    fun withSession(request: Request): Request {
        val extra = sessionHeaders(request.url.toString())
        if (extra.isEmpty()) return request
        val b = request.newBuilder()
        extra["Cookie"]?.let { web ->
            val merged = LinkedHashMap<String, String>()
            cookieMap(request.header("Cookie").orEmpty(), merged)
            cookieMap(web, merged)
            b.header("Cookie", merged.entries.joinToString("; ") { it.key + "=" + it.value })
        }
        extra["User-Agent"]?.let { b.header("User-Agent", it) }
        return b.build()
    }

    /** Is this answer a browser check / login wall that a person has to pass? */
    fun detect(response: Response): Kind? {
        val code = response.code
        if (code != 403 && code != 503 && code != 429 && code != 401) return null
        if (response.header("cf-mitigated").equals("challenge", ignoreCase = true)) return Kind.AUTO
        val contentType = response.header("Content-Type")?.lowercase().orEmpty()
        if (!contentType.contains("html")) return null
        val server = response.header("Server")?.lowercase().orEmpty()
        val body = try { response.peekBody(96 * 1024L).string().lowercase() } catch (_: Throwable) { "" }
        if (server.contains("cloudflare")) {
            if ((code == 403 || code == 503) || CF_MARKERS.any { body.contains(it) }) return Kind.AUTO
            return null
        }
        if (code == 429) return null
        if (OTHER_MARKERS.any { body.contains(it) } || body.contains("just a moment")) return Kind.MANUAL
        if (code == 401 && LOGIN_MARKERS.any { body.contains(it) }) return Kind.MANUAL
        return null
    }

    fun onCooldown(host: String): Boolean = (cooldownUntil[host] ?: 0L) > System.currentTimeMillis()

    fun markStillBlocked(host: String) {
        cooldownUntil[host] = System.currentTimeMillis() + BLOCKED_COOLDOWN_MS
        doneAt.remove(host)
    }

    /** true = the check is passed (or was passed a moment ago) and the request should be repeated. */
    suspend fun solve(url: String, kind: Kind): Boolean {
        val host = try { java.net.URI(url).host } catch (_: Throwable) { null } ?: return false
        val lock = locks.getOrPut(host) { Mutex() }
        return lock.withLock {
            val now = System.currentTimeMillis()
            if ((cooldownUntil[host] ?: 0L) > now) return@withLock false
            // a parallel request of the same site finished the check while this one waited
            if ((doneAt[host] ?: 0L) > now - 20_000L) return@withLock true
            // cookies of an earlier session (before an app restart) may still be valid: try them once before asking
            if (kind == Kind.AUTO && savedTried.add(host) && webCookies(url).contains("cf_clearance")) {
                sessionHosts.add(host)
                return@withLock true
            }
            val ctx = CloudStreamApp.context ?: return@withLock false
            val ok = runBrowser(ctx, url, host, kind)
            if (ok) {
                sessionHosts.add(host)
                doneAt[host] = System.currentTimeMillis()
            } else {
                cooldownUntil[host] = System.currentTimeMillis() + CANCEL_COOLDOWN_MS
            }
            ok
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun runBrowser(ctx: Context, url: String, host: String, kind: Kind): Boolean =
        withContext(Dispatchers.Main) {
            val done = CompletableDeferred<Boolean>()
            val handler = Handler(Looper.getMainLooper())
            val cm = CookieManager.getInstance()
            try { cm.setAcceptCookie(true) } catch (_: Throwable) {}
            val wv = WebView(ctx)
            var finished = false
            var shownId = 0L
            var sawChallenge = false
            var loadedAt = 0L
            val startedAt = System.currentTimeMillis()
            val initialClearance = cookieValue(webCookies(url), "cf_clearance")

            fun cleanup() {
                handler.removeCallbacksAndMessages(null)
                if (shownId != 0L) {
                    try { WebViewResolver.hideBrowser?.invoke(shownId) } catch (_: Throwable) {}
                    shownId = 0L
                    InAppBrowserGate.open.decrementAndGet()
                }
                try { wv.stopLoading() } catch (_: Throwable) {}
                // destroyed a moment later: the dialog still has to detach the view
                Handler(Looper.getMainLooper()).postDelayed({ try { wv.destroy() } catch (_: Throwable) {} }, 500L)
            }

            fun finish(ok: Boolean) {
                if (finished) return
                finished = true
                try { cm.flush() } catch (_: Throwable) {}
                cleanup()
                done.complete(ok)
            }

            wv.settings.javaScriptEnabled = true
            wv.settings.domStorageEnabled = true
            try { cm.setAcceptThirdPartyCookies(wv, true) } catch (_: Throwable) {}
            // the default WebView user agent: Cloudflare ties its clearance cookie to it
            WebViewResolver.webViewUserAgent = wv.settings.userAgentString
            wv.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, u: String?) {
                    loadedAt = System.currentTimeMillis()
                }
            }

            val poll = object : Runnable {
                override fun run() {
                    if (finished) return
                    val now = System.currentTimeMillis()
                    if (kind == Kind.AUTO) {
                        val clearance = cookieValue(webCookies(url), "cf_clearance")
                        if (!clearance.isNullOrEmpty() && clearance != initialClearance) { finish(true); return }
                        if (loadedAt > 0L && now - loadedAt > 1_500L) {
                            val title = (wv.title ?: "").lowercase()
                            if (CHALLENGE_TITLES.any { title.contains(it) }) sawChallenge = true
                            else if (sawChallenge) { finish(true); return }
                        }
                    }
                    // a tap / captcha / login cannot be done while hidden: the page is shown in the app (a login page at once)
                    if (shownId == 0L && (kind == Kind.MANUAL || now - startedAt > AUTO_SHOW_DELAY_MS)) {
                        val show = WebViewResolver.showBrowser
                        if (show != null) {
                            shownId = show(wv, host) { handler.post { finish(true) } }
                            if (shownId != 0L) InAppBrowserGate.open.incrementAndGet()
                        }
                    }
                    val limit = if (shownId != 0L) MANUAL_TIMEOUT_MS else AUTO_TIMEOUT_MS
                    if (now - startedAt > limit) { finish(false); return }
                    handler.postDelayed(this, 600L)
                }
            }
            try {
                wv.loadUrl(url)
            } catch (_: Throwable) {
                finish(false)
            }
            handler.postDelayed(poll, 800L)
            try {
                done.await()
            } finally {
                if (!finished) {
                    finished = true
                    cleanup()
                }
            }
        }
}

/** Added to the default HTTP client of the CloudStream engine: hands a browser check / login wall to the in-app browser. */
class BrowserChallengeInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val response = chain.proceed(BrowserChallenge.withSession(original))
        val kind = BrowserChallenge.detect(response) ?: return response
        val host = original.url.host
        // a WebViewResolver / CloudflareKiller run is already working on this; its own sub-requests must not open a second browser
        if (InAppBrowserGate.resolvers.get() > 0 || BrowserChallenge.onCooldown(host)) return response
        val ok = try {
            runBlocking { BrowserChallenge.solve(original.url.toString(), kind) }
        } catch (_: Throwable) {
            false
        }
        if (!ok) return response
        response.close()
        val retry = chain.proceed(BrowserChallenge.withSession(original))
        if (BrowserChallenge.detect(retry) != null) BrowserChallenge.markStillBlocked(host)
        return retry
    }
}
