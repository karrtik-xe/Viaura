/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

package com.example.data.lyrics.providers

import com.example.domain.lyrics.Lyrics
import com.example.domain.lyrics.LyricsProvider
import org.json.JSONObject
import kotlin.math.abs

/**
 * Line-synced lyrics from NetEase Cloud Music's public web endpoints: a very large catalogue that also holds most
 * Hindi / Punjabi / English hits with accurate LRC timing. Two unauthenticated calls: search the song, then download
 * the lyric of the best cuts (the ones within the duration tolerance of the playing file).
 */
internal object NetEaseProvider : LyricsProviderClient {
  override val id: LyricsProvider = LyricsProvider.NETEASE

  private const val DURATION_TOLERANCE_SECONDS = 8
  private const val MAX_LOOKUPS = 3
  private val HEADERS = mapOf("Referer" to "https://music.163.com/", "Accept" to "application/json")
  private val CREDIT =
    Regex("""^\[[^\]]*](?:作词|作曲|编曲|制作人|制作|混音|母带|录音|监制|和声|吉他|贝斯|鼓|词|曲|Lyrics?\s*(?:by)?|Compos(?:ed|er)\s*(?:by)?|Arrang(?:ed|er)\s*(?:by)?|Produc(?:ed|er)\s*(?:by)?)\s*[:：].*$""", RegexOption.IGNORE_CASE)
  private val INSTRUMENTAL = listOf("纯音乐，请欣赏", "纯音乐, 请欣赏", "此歌曲为没有填词的纯音乐")

  private data class Song(val id: Long, val title: String, val artist: String, val durationSec: Double)

  override suspend fun fetch(query: LyricsFetchQuery): Lyrics? {
    val seconds = query.durationMs / 1000
    for (ref in query.candidates()) {
      val url =
        buildUrl(
          "https://music.163.com/api/search/get",
          "type" to "1",
          "limit" to "10",
          "s" to "${ref.title.stripBrackets()} ${ref.artist.stripBrackets()}".trim(),
        ) ?: continue
      val body = lyricsGet(url, HEADERS) ?: continue
      val songs = runCatching { parseSongs(body) }.getOrNull().orEmpty()
      val shortlist =
        songs
          .filter { LyricsTrackMatcher.matches(ref.copy(artist = ""), it.title, null, seconds, it.durationSec) }
          .filter { seconds <= 0 || it.durationSec <= 0.0 || abs(it.durationSec - seconds) <= DURATION_TOLERANCE_SECONDS }
          .sortedBy { if (seconds > 0 && it.durationSec > 0.0) abs(it.durationSec - seconds) else 0.0 }
          .take(if (seconds > 0) MAX_LOOKUPS else 1)
      for (song in shortlist) {
        val lyricUrl =
          buildUrl("https://music.163.com/api/song/lyric", "id" to song.id.toString(), "lv" to "1", "kv" to "1", "tv" to "-1")
            ?: continue
        val lyricBody = lyricsGet(lyricUrl, HEADERS) ?: continue
        parseLyric(lyricBody)?.let { return it }
      }
    }
    return null
  }

  private fun String.stripBrackets(): String = replace(Regex("""[(（\[].*?[)）\]]"""), "").trim().ifBlank { this }

  private fun parseSongs(body: String): List<Song> {
    val songs = JSONObject(body).optJSONObject("result")?.optJSONArray("songs") ?: return emptyList()
    return (0 until songs.length()).mapNotNull { index ->
      val song = songs.optJSONObject(index) ?: return@mapNotNull null
      val songId = song.optLong("id")
      val title = song.optString("name").trim()
      if (songId <= 0L || title.isBlank()) return@mapNotNull null
      val artists = song.optJSONArray("artists")
      val artist =
        (0 until (artists?.length() ?: 0))
          .mapNotNull { artists?.optJSONObject(it)?.optString("name")?.trim()?.takeIf(String::isNotBlank) }
          .joinToString(", ")
      Song(songId, title, artist, song.optLong("duration") / 1000.0)
    }
  }

  private fun parseLyric(body: String): Lyrics? {
    val json = JSONObject(body)
    if (json.optBoolean("nolyric") || json.optBoolean("uncollected")) return null
    val raw = json.optJSONObject("lrc")?.optString("lyric").orEmpty()
    if (raw.isBlank() || INSTRUMENTAL.any { raw.contains(it) }) return null
    val cleaned =
      raw
        .lines()
        .let { lines ->
          // credit lines (lyricist, composer ...) carry real stamps near the start and would be sung as lyrics
          var cut = 0
          while (cut < lines.size && cut < 12 && (CREDIT.matches(lines[cut].trim()) || lines[cut].isBlank())) cut++
          lines.drop(cut)
        }.filterNot { CREDIT.matches(it.trim()) }
        .joinToString("\n")
    return parseLrcText(cleaned)
  }
}
