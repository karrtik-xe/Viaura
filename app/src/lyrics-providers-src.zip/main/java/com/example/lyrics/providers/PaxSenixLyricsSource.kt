/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * Derived from BitChord's PaxSenix provider
 * (https://github.com/kushagrasinghx/BitChord), GPL-3.0-or-later.
 */

package com.example.data.lyrics.providers

import com.example.domain.lyrics.Lyrics
import com.example.domain.lyrics.LyricsProvider
import com.example.domain.lyrics.SyncedLine
import com.example.domain.lyrics.SyncedWord
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.longOrNull
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

internal fun normalizeApiKey(value: String): String {
  val trimmed = value.trim()
  return if (trimmed.startsWith("Bearer ", ignoreCase = true)) trimmed.substringAfter(' ').trim() else trimmed
}

/** The single PaxSenix route a provider instance stands for. */
internal enum class PaxSenixRoute { APPLE, SPOTIFY, MUSIXMATCH }

internal class PaxSenixProvider(
  override val id: LyricsProvider,
  private val route: PaxSenixRoute,
) : LyricsProviderClient {
  override suspend fun fetch(query: LyricsFetchQuery): Lyrics? =
    when (route) {
      PaxSenixRoute.APPLE -> PaxSenixApi.appleLyrics(query)
      PaxSenixRoute.SPOTIFY -> PaxSenixApi.spotifyLyrics(query)
      PaxSenixRoute.MUSIXMATCH -> PaxSenixApi.musixmatchLyrics(query)
    }
}
