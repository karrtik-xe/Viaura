/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

package com.example.data.lyrics.providers

import com.example.domain.lyrics.Lyrics
import com.example.domain.lyrics.LyricsProvider

/** One title/artist pair a lookup was given, as the playing file described it. */
data class TrackRef(
  val title: String,
  val artist: String,
) {
  fun isUsable(): Boolean = title.isNotBlank()

  fun key(): String = "${title.trim()}|${artist.trim()}".lowercase()
}

/**
 * Everything a provider is told about the track being played.
 *
 * [refs] is ordered and already cleaned — the repository does the guessing about
 * which segment of a YouTube title is the artist, which part of an
 * "Artist - Title" line is which, and hands every provider the same list. A
 * provider walks it until something matches rather than re-deriving names for
 * itself, so a miss means "not in this catalogue" and not "asked the wrong way".
 */
data class LyricsFetchQuery(
  val refs: List<TrackRef>,
  val durationMs: Int = 0,
  val album: String? = null,
  val videoId: String? = null,
  val isrc: String? = null,
  /**
   * Real length of the playing file. [durationMs] is 0 on the relaxed second pass (no length check, so another edit of the same
   * song can still be found); this field keeps the file length so the found lyrics can be fitted to the audio afterwards.
   */
  val fileDurationMs: Int = 0,
  /** +1 when the title says slowed / reverb, -1 for sped up / nightcore, else 0. Used when fitting lyrics to another edit. */
  val speedHint: Int = 0,
  /** True when the title says this is a music video (intro / skit before the song), so the lyrics may start late. */
  val videoHint: Boolean = false,
) {
  /** The lookup as the metadata states it, before any of the guesses. */
  val primary: TrackRef
    get() = refs.firstOrNull() ?: TrackRef("", "")

  /** Candidate names to try, bounded so one provider cannot fan out into a storm. */
  fun candidates(limit: Int = MAX_CANDIDATES): List<TrackRef> =
    refs
      .asSequence()
      .filter { it.isUsable() }
      .distinctBy { it.key() }
      .take(limit)
      .toList()

  companion object {
    const val MAX_CANDIDATES: Int = 4
  }
}

/**
 * One online lyrics database, reachable the same way as every other.
 *
 * Implementations are expected to fail quietly: a provider that is geoblocked,
 * rate-limited or simply missing this track returns null and lets the race move
 * on. Throwing is reserved for genuine programmer errors, never for a miss.
 */
interface LyricsProviderClient {
  val id: LyricsProvider

  suspend fun fetch(query: LyricsFetchQuery): Lyrics?
}
