/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

package com.example.data.lyrics.providers

import com.example.domain.lyrics.Lyrics
import com.example.domain.lyrics.LyricsProvider
import org.json.JSONObject
import kotlin.math.abs

/**
 * Plain lyrics from JioSaavn, the catalogue that carries the Hindi, Punjabi and regional songs the global databases
 * lack. Two unauthenticated calls: search the song (only songs that have lyrics), then fetch the lyrics of the cut that
 * matches the playing file's length. Text only: it is the fallback when nothing timed exists.
 */
internal object JioSaavnProvider : LyricsProviderClient {
  override val id: LyricsProvider = LyricsProvider.JIOSAAVN

  private const val API = "https://www.jiosaavn.com/api.php"
  private const val DURATION_TOLERANCE_SECONDS = 8
  private val BREAK = Regex("""(?i)<br\s*/?>|</?(?:p|div)(?:\s[^>]*)?>""")
  private val TAG = Regex("""<[^>]+>""")

  private data class Song(val id: String, val title: String, val artist: String, val durationSec: Double)

  override suspend fun fetch(query: LyricsFetchQuery): Lyrics? {
    val seconds = query.durationMs / 1000
    for (ref in query.candidates()) {
      val url =
        buildUrl(
          API,
          "__call" to "search.getResults",
          "_format" to "json",
          "_marker" to "0",
          "api_version" to "4",
          "ctx" to "web6dot0",
          "n" to "10",
          "p" to "1",
          "q" to "${ref.title} ${ref.artist}".trim(),
        ) ?: continue
      val body = lyricsGet(url) ?: continue
      val songs = runCatching { parseSongs(body) }.getOrNull().orEmpty()
      val shortlist =
        songs
          .filter { LyricsTrackMatcher.matches(ref.copy(artist = ""), it.title, null, seconds, it.durationSec) }
          .filter { seconds <= 0 || it.durationSec <= 0.0 || abs(it.durationSec - seconds) <= DURATION_TOLERANCE_SECONDS }
          .sortedBy { if (seconds > 0 && it.durationSec > 0.0) abs(it.durationSec - seconds) else 0.0 }
          .take(2)
      for (song in shortlist) {
        val lyricUrl =
          buildUrl(
            API,
            "__call" to "lyrics.getLyrics",
            "_format" to "json",
            "_marker" to "0",
            "api_version" to "4",
            "ctx" to "web6dot0",
            "lyrics_id" to song.id,
          ) ?: continue
        val lyricBody = lyricsGet(lyricUrl) ?: continue
        val raw = runCatching { JSONObject(lyricBody).optString("lyrics") }.getOrNull().orEmpty()
        if (raw.isBlank()) continue
        val text = decodeEntities(raw.replace(BREAK, "\n").replace(TAG, "")).trim()
        lyricsFromPlain(text)?.let { return it }
      }
    }
    return null
  }

  private fun parseSongs(body: String): List<Song> {
    val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
    return (0 until results.length()).mapNotNull { index ->
      val song = results.optJSONObject(index) ?: return@mapNotNull null
      val info = song.optJSONObject("more_info") ?: return@mapNotNull null
      val songId = song.optString("id").trim()
      if (songId.isBlank() || song.optString("type") != "song" || info.optString("has_lyrics") != "true") return@mapNotNull null
      val artists = info.optJSONObject("artistMap")?.optJSONArray("primary_artists")
      val artist =
        (0 until (artists?.length() ?: 0))
          .mapNotNull { artists?.optJSONObject(it)?.optString("name")?.let(::decodeEntities)?.takeIf(String::isNotBlank) }
          .joinToString(", ")
      Song(
        songId,
        decodeEntities(song.optString("title")).trim(),
        artist,
        info.optString("duration").toDoubleOrNull() ?: 0.0,
      )
    }
  }
}
