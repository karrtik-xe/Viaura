/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

package com.example.data.lyrics.providers

import com.example.domain.lyrics.Lyrics
import com.example.domain.lyrics.LyricsProvider
import com.example.domain.lyrics.SyncedLine
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull

internal object YouTubeMusicLyricsProvider : LyricsProviderClient {
  override val id: LyricsProvider = LyricsProvider.YOUTUBE_MUSIC

  private const val KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
  private const val NEXT = "https://music.youtube.com/youtubei/v1/next"
  private const val BROWSE = "https://music.youtube.com/youtubei/v1/browse"
  private const val CLIENT_VERSION = "1.20250101.01.00"

  override suspend fun fetch(query: LyricsFetchQuery): Lyrics? {
    val videoId = query.videoId?.takeIf(SimpMusicProvider.YOUTUBE_ID::matches) ?: return null
    val next = postJson(NEXT, clientContext() + ""","videoId":"$videoId"""") ?: return null
    val shelf =
      next
        .objectsNamed("tabRenderer")
        .firstOrNull { tab -> tab.youtubeStrings().any { it.equals("Lyrics", ignoreCase = true) } }
        ?.objectsNamed("browseEndpoint")
        ?.firstOrNull()
        ?: return null
    val browseId = shelf.string("browseId") ?: return null
    val params = shelf.string("params")

    val request =
      buildString {
        append(clientContext())
        append(""","browseId":${quote(browseId)}""")
        if (!params.isNullOrBlank()) append(""","params":${quote(params)}""")
        append('}')
      }
    val browse = postJson(BROWSE, request) ?: return null
    val text =
      browse
        .objectsNamed("musicDescriptionShelfRenderer")
        .firstOrNull()
        ?.let { shelfElement -> shelfElement["description"]?.youtubeStrings()?.joinToString("\n") }
        .orEmpty()
        .trim()
    return lyricsFromPlain(text)
  }

  private fun clientContext(): String =
    """{"context":{"client":{"clientName":"WEB_REMIX","clientVersion":"$CLIENT_VERSION","hl":"en"}}}"""

  private fun quote(value: String): String = "\"" + value.replace("\"", "\\\"") + "\""

  private suspend fun postJson(
    url: String,
    body: String,
  ): JsonObject? {
    val response = lyricsPost(url = "$url?key=$KEY", body = body) ?: return null
    return runCatching { lyricsJson.parseToJsonElement(response) }.getOrNull() as? JsonObject
  }
}

internal val BROWSER_HEADERS =
  mapOf(
    "User-Agent" to (
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept-Language" to "en-US,en;q=0.9",
  )

/** Depth-first walk over every object in a document, whatever it is nested under. */
internal fun JsonElement?.objectsNamed(name: String): Sequence<JsonObject> =
  sequence {
    when (this@objectsNamed) {
      is JsonObject ->
        for ((key, value) in this@objectsNamed) {
          if (key == name) {
            when (value) {
              is JsonObject -> yield(value)
              is JsonArray -> for (item in value) if (item is JsonObject) yield(item)
              else -> Unit
            }
          }
          yieldAll(value.objectsNamed(name))
        }
      is JsonArray -> for (value in this@objectsNamed) yieldAll(value.objectsNamed(name))
      else -> Unit
    }
  }

private fun JsonElement?.youtubeStrings(): List<String> =
  when (this) {
    is JsonPrimitive -> contentOrNull?.let(::listOf).orEmpty()
    is JsonArray -> flatMap { it.youtubeStrings() }
    is JsonObject -> {
      val direct = string("text") ?: string("simpleText")
      direct?.let(::listOf) ?: values.flatMap { it.youtubeStrings() }
    }
    else -> emptyList()
  }

internal fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull
