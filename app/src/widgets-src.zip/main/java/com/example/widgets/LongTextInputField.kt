package com.example.ui.components

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AccentSkyBlue

/**
 * Single-line text field for long text (file names, API keys, URLs).
 *
 *  - the caret is always kept in view: moving it with the keyboard's space-bar / cursor slider or the selection
 *    handles scrolls the text automatically (the plain BasicTextField stopped at the box edge),
 *  - the text can also be panned left / right with a finger drag,
 *  - the WHOLE box (including [contentPadding]) is the touch area: tapping anywhere inside focuses the field and
 *    opens the keyboard.
 */
@Composable
fun FollowCursorTextField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: TextStyle = TextStyle.Default,
    cursorBrush: Brush = SolidColor(AccentSkyBlue),
    placeholder: String? = null,
    placeholderColor: Color = Color.Gray,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    focusRequester: FocusRequester? = null,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    minHeight: androidx.compose.ui.unit.Dp = 44.dp,
    onFocusChanged: ((Boolean) -> Unit)? = null
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val fr = focusRequester ?: remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    var viewportPx by remember { mutableIntStateOf(0) }
    val marginPx = with(density) { 28.dp.toPx() }

    // keep the caret visible whenever it (or the text / viewport) changes
    LaunchedEffect(value.selection.end, value.text, layout, viewportPx, scroll.maxValue) {
        val l = layout ?: return@LaunchedEffect
        if (viewportPx <= 0) return@LaunchedEffect
        val len = l.layoutInput.text.length
        val off = value.selection.end.coerceIn(0, len)
        val rect = try { l.getCursorRect(off) } catch (_: Throwable) { return@LaunchedEffect }
        val cur = scroll.value
        val target = when {
            rect.left - marginPx < cur -> (rect.left - marginPx).toInt().coerceAtLeast(0)
            rect.right + marginPx > cur + viewportPx -> (rect.right + marginPx - viewportPx).toInt()
            else -> cur
        }
        if (target != cur) scroll.scrollTo(target)
    }

    Box(
        modifier = modifier
            .heightIn(min = minHeight)
            .pointerInput(Unit) {
                detectTapGestures {
                    try { fr.requestFocus() } catch (_: Throwable) {}
                    keyboard?.show()
                }
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(contentPadding)
                .clipToBounds()
                .onSizeChanged { viewportPx = it.width }
        ) {
            val viewportDp = with(density) { viewportPx.toDp() }
            Box(modifier = Modifier.horizontalScroll(scroll)) {
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier
                        .widthIn(min = viewportDp)
                        .padding(end = 8.dp)
                        .focusRequester(fr)
                        .onFocusChanged { onFocusChanged?.invoke(it.isFocused) },
                    textStyle = textStyle,
                    singleLine = true,
                    cursorBrush = cursorBrush,
                    visualTransformation = visualTransformation,
                    keyboardOptions = keyboardOptions,
                    keyboardActions = keyboardActions,
                    onTextLayout = { layout = it },
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (value.text.isEmpty() && !placeholder.isNullOrEmpty()) {
                                Text(
                                    text = placeholder,
                                    style = textStyle,
                                    color = placeholderColor,
                                    maxLines = 1
                                )
                            }
                            inner()
                        }
                    }
                )
            }
        }
    }
}

/** String version: keeps the caret / selection state itself. */
@Composable
fun FollowCursorTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: TextStyle = TextStyle.Default,
    cursorBrush: Brush = SolidColor(AccentSkyBlue),
    placeholder: String? = null,
    placeholderColor: Color = Color.Gray,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    focusRequester: FocusRequester? = null,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    minHeight: androidx.compose.ui.unit.Dp = 44.dp,
    onFocusChanged: ((Boolean) -> Unit)? = null
) {
    var tfv by remember { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    // the parent may change / reject the text (e.g. digits only): follow it
    val shown = if (tfv.text == value) tfv else TextFieldValue(value, TextRange(value.length))
    FollowCursorTextField(
        value = shown,
        onValueChange = {
            tfv = it
            if (it.text != value) onValueChange(it.text)
        },
        modifier = modifier,
        textStyle = textStyle,
        cursorBrush = cursorBrush,
        placeholder = placeholder,
        placeholderColor = placeholderColor,
        visualTransformation = visualTransformation,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        focusRequester = focusRequester,
        contentPadding = contentPadding,
        minHeight = minHeight,
        onFocusChanged = onFocusChanged
    )
}
