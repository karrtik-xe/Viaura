package com.example.ui.components

import com.example.ui.theme.Neutral

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SortByAlpha
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.state.ThemeMode
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.DarkGlassSurface
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.LightGlassBorder
import com.example.ui.theme.LightGlassSurface
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary

@Composable
fun HeaderBar(
    title: String,
    themeMode: ThemeMode,
    modifier: Modifier = Modifier,
    onSettingsClick: (() -> Unit)? = null,
    subtitle: String? = null,
    /** Small raised tag after the title, e.g. "(Beta)" on the Home screen of a beta build. */
    titleSuffix: String? = null,
    onBackClick: (() -> Unit)? = null,
    onSearchClick: (() -> Unit)? = null,
    onSortClick: (() -> Unit)? = null,
    onCopyClick: (() -> Unit)? = null,
    onShareClick: (() -> Unit)? = null,
    onDownloadClick: (() -> Unit)? = null,
    leadingIconUrl: String? = null,
    backgroundColor: Color? = null,
    showBorder: Boolean = true,
    elevation: Dp = 6.dp
) {
    val isDark = themeMode == ThemeMode.DARK ||
        (themeMode == ThemeMode.SYSTEM && androidx.compose.foundation.isSystemInDarkTheme())
    val surfaceColor = backgroundColor ?: (if (isDark) DarkGlassSurface else LightGlassSurface)
    val borderColor = if (isDark) DarkGlassBorder else LightGlassBorder
    val textColor = if (isDark) DarkTextPrimary else LightTextPrimary
    val subtextColor = if (isDark) DarkTextSecondary else LightTextSecondary

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(58.dp)
            // Liquid Glass: frosted pill with specular border; OFF = the original bar
            .liquidGlassOr(RoundedCornerShape(16.dp), isDark, LocalPanelTransparency.current, elevation = elevation, backdropBlur = false) {
                this
                    .then(
                        if (elevation > 0.dp) {
                            Modifier.shadow(
                                elevation = elevation,
                                shape = RoundedCornerShape(16.dp),
                                ambientColor = Color.Black.copy(alpha = 0.12f),
                                spotColor = Color.Black.copy(alpha = 0.16f)
                            )
                        } else Modifier
                    )
                    .clip(RoundedCornerShape(16.dp))
                    .background(surfaceColor)
                    .then(
                        if (showBorder) {
                            Modifier.border(1.dp, borderColor, RoundedCornerShape(16.dp))
                        } else Modifier
                    )
            }
            .padding(horizontal = 14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxSize()
        ) {
            // Left Side: Back button OR App Icon
            if (onBackClick != null) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("header_back_button")
                        .clip(CircleShape)
                        .bounceClick(onClick = onBackClick),
                    contentAlignment = Alignment.Center
                ) {
                    StyledIcon(
                                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = "Back",
                        tint = textColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
            } else if (leadingIconUrl != null) {
                // a media provider page: the provider's own icon instead of the app icon
                LinkThumbnail(
                    thumbnail = leadingIconUrl.ifBlank { null },
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("header_provider_icon")
                        .clip(RoundedCornerShape(10.dp)),
                    fallback = {
                        Image(
                            painter = painterResource(id = R.drawable.ic_abouticon),
                            contentDescription = "Provider",
                            modifier = Modifier.size(34.dp)
                        )
                    }
                )
            } else {
                // app icon with the same sliding gradient + moving shine as the settings icon
                ShineLogoIcon(
                    iconSize = 34.dp,
                    contentDescription = "Viaura Logo",
                    modifier = Modifier.testTag("header_app_icon")
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (titleSuffix.isNullOrBlank()) androidx.compose.ui.text.AnnotatedString(title) else buildAnnotatedString {
                        append(title)
                        // thin gap (close to the name), small raised tag; "Beta" sits a touch lower than the brackets so it looks
                        // centred between them (round brackets reach below the baseline, letters do not)
                        append("\u2009")
                        val word = titleSuffix.trim().removePrefix("(").removeSuffix(")")
                        withStyle(SpanStyle(fontSize = 9.sp, fontWeight = FontWeight.Medium, baselineShift = BaselineShift(0.50f))) { append("(") }
                        withStyle(SpanStyle(fontSize = 8.5.sp, fontWeight = FontWeight.Medium, baselineShift = BaselineShift(0.42f))) { append(word) }
                        withStyle(SpanStyle(fontSize = 9.sp, fontWeight = FontWeight.Medium, baselineShift = BaselineShift(0.50f))) { append(")") }
                    },
                    fontSize = if (!subtitle.isNullOrBlank()) 16.5.sp else 18.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = textColor,
                    letterSpacing = (-0.3).sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        lineHeight = 13.sp,
                        color = subtextColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Right side icons:
            // 1. Search icon (leftmost)
            if (onSearchClick != null) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("search_button")
                        .clip(CircleShape)
                        .bounceClick(onClick = onSearchClick),
                    contentAlignment = Alignment.Center
                ) {
                    StyledIcon(
                                imageVector = Icons.Outlined.Search,
                        contentDescription = "Search",
                        tint = textColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(2.dp))
            }

            // 2. Context action: either normal Sort, or Copy + Share on information pages.
            if (onCopyClick != null) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("copy_button")
                        .clip(CircleShape)
                        .bounceClick(onClick = onCopyClick),
                    contentAlignment = Alignment.Center
                ) {
                    StyledIcon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = "Copy",
                        tint = textColor,
                        modifier = Modifier.size(21.dp)
                    )
                }
                Spacer(modifier = Modifier.width(2.dp))
            } else if (onSortClick != null) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("sort_button")
                        .clip(CircleShape)
                        .bounceClick(onClick = onSortClick),
                    contentAlignment = Alignment.Center
                ) {
                    StyledIcon(
                        imageVector = Icons.Outlined.SortByAlpha,
                        contentDescription = "Sort & View Options",
                        tint = textColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(2.dp))
            } else if (onDownloadClick != null) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("download_button")
                        .clip(CircleShape)
                        .bounceClick(onClick = onDownloadClick),
                    contentAlignment = Alignment.Center
                ) {
                    StyledIcon(
                        drawableRes = R.drawable.viaura_downloads,
                        contentDescription = "Downloads",
                        tint = textColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(2.dp))
            }

            if (onShareClick != null) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("share_button")
                        .clip(CircleShape)
                        .bounceClick(onClick = onShareClick),
                    contentAlignment = Alignment.Center
                ) {
                    StyledIcon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share",
                        tint = textColor,
                        modifier = Modifier.size(21.dp)
                    )
                }
                Spacer(modifier = Modifier.width(2.dp))
            }

            // 3. Settings gear icon (rightmost)
            if (onSettingsClick != null) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("settings_button")
                        .clip(CircleShape)
                        .bounceClick(onClick = onSettingsClick),
                    contentAlignment = Alignment.Center
                ) {
                    StyledIcon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Settings",
                        tint = textColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}
