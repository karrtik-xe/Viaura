package com.example.ui.components

import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import com.example.R

@Composable
fun StyledIcon(
    drawableRes: Int,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current
) {
    Icon(
        painter = painterResource(drawableRes),
        contentDescription = contentDescription,
        modifier = modifier,
        tint = tint
    )
}

@Composable
fun StyledIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current
) {
    val key = imageVector.name.substringAfterLast('.')
    val resId = when (key) {
        "PhoneAndroid" -> R.drawable.viaura_smartphone
        "Cast" -> R.drawable.viaura_screencast
        "BookmarkBorder" -> R.drawable.viaura_bookmark
        "Memory" -> R.drawable.viaura_cpu
        "MusicNote" -> R.drawable.viaura_song
        "Subtitles" -> R.drawable.viaura_subtitles
        "DashboardCustomize" -> R.drawable.viaura_widget_5
        "MoreVert" -> R.drawable.viaura_menu_dots
        "Headphones" -> R.drawable.viaura_headphones_round
        "LockOpen" -> R.drawable.viaura_lock_unlocked
        "ScreenRotation" -> R.drawable.viaura_smartphone_rotate_orientation
        "Speed" -> R.drawable.viaura_speed
        "Repeat" -> R.drawable.viaura_repeat
        "Shuffle" -> R.drawable.viaura_shuffle
        "AllInclusive" -> R.drawable.viaura_ab_loop
        "CameraAlt" -> R.drawable.viaura_screenshot
        "ZoomIn" -> R.drawable.viaura_magnifer_zoom_in
        "PictureInPictureAlt" -> R.drawable.viaura_pip
        "AspectRatio" -> R.drawable.viaura_minimize_square_2
        "GraphicEq" -> R.drawable.viaura_equalizer
        "VideoLibrary" -> R.drawable.viaura_video_library
        "Lightbulb" -> R.drawable.viaura_ambience
        "VideoFile", "Videocam" -> R.drawable.viaura_video
        "Audiotrack" -> R.drawable.viaura_song
        "AccessTime" -> R.drawable.viaura_clock_circle
        "VolumeUp" -> R.drawable.viaura_volume_loud
        "WbSunny", "BrightnessMedium" -> R.drawable.viaura_sun
        "BrightnessLow" -> R.drawable.viaura_sun_2
        "Search" -> R.drawable.viaura_magnifer
        "Settings" -> R.drawable.viaura_settings
        "SortByAlpha" -> R.drawable.viaura_sort_by_alphabet
        "Add" -> R.drawable.viaura_add_circle
        "Check", "CheckCircle", "DoneAll" -> R.drawable.viaura_check_circle
        "ChevronLeft" -> R.drawable.viaura_arrow_left_solid
        "ChevronRight" -> R.drawable.viaura_arrow_right_solid
        "Clear", "Close" -> R.drawable.viaura_close_circle
        "CreateNewFolder" -> R.drawable.viaura_add_folder
        "DarkMode" -> R.drawable.viaura_moon
        "Description" -> R.drawable.viaura_document_text
        "Download" -> R.drawable.viaura_download_minimalistic
        "DragIndicator", "DragHandle" -> R.drawable.viaura_reorder
        "ExpandLess", "KeyboardArrowUp" -> R.drawable.viaura_list_arrow_up
        "ExpandMore", "KeyboardArrowDown", "ArrowDropDown" -> R.drawable.viaura_list_arrow_down
        "Folder" -> R.drawable.viaura_folder
        "FolderOff" -> R.drawable.viaura_folder_error
        "FolderOpen" -> R.drawable.viaura_folder_open
        "FolderSpecial" -> R.drawable.viaura_folder_favourite_star
        "FolderZip" -> R.drawable.viaura_winrar
        "FontDownload" -> R.drawable.viaura_text
        "FormatListBulleted" -> R.drawable.viaura_list
        "GridView" -> R.drawable.viaura_widget_5
        "History" -> R.drawable.viaura_recent
        "Lock" -> R.drawable.viaura_lock
        "Movie" -> R.drawable.viaura_video
        "Palette" -> R.drawable.viaura_pallete_2
        "PlaylistPlay" -> R.drawable.viaura_playlist_video
        "Remove" -> R.drawable.viaura_minus_circle
        "RepeatOne" -> R.drawable.viaura_repeat_one
        "RestartAlt" -> R.drawable.viaura_restart
        "Save" -> R.drawable.viaura_download_square
        "Security" -> R.drawable.viaura_shield_check
        "Storage" -> R.drawable.viaura_folder_with_files
        "SubdirectoryArrowRight", "ArrowForwardIos" -> R.drawable.viaura_arrow_right_solid
        "SurroundSound" -> R.drawable.viaura_audio_circle
        "SwapHoriz" -> R.drawable.viaura_sort_horizontal
        "SwapVert" -> R.drawable.viaura_sort_vertical
        "Timelapse" -> R.drawable.viaura_clock_circle
        "Title" -> R.drawable.viaura_text
        "Translate" -> R.drawable.viaura_translation
        "UploadFile" -> R.drawable.viaura_upload_minimalistic
        "ViewList" -> R.drawable.viaura_list
        "Visibility" -> R.drawable.viaura_eye
        "VisibilityOff" -> R.drawable.viaura_eye_closed
        "VolumeDown" -> R.drawable.viaura_volume_small
        "VolumeOff" -> R.drawable.viaura_volume_cross
        "VolumeMute" -> R.drawable.viaura_volume
        "FastForward" -> R.drawable.viaura_rewind_forward
        "FastRewind" -> R.drawable.viaura_rewind_back
        "Favorite" -> R.drawable.viaura_heart
        "Pause" -> R.drawable.viaura_pause_solid
        "PlayArrow" -> R.drawable.viaura_play_solid
        "SkipNext" -> R.drawable.viaura_arrow_right_solid
        "SkipPrevious" -> R.drawable.viaura_arrow_left_solid
        "ArrowBack" -> R.drawable.viaura_leave
        "ArrowForward" -> R.drawable.viaura_arrow_right_solid
        "SubtitlesOff" -> R.drawable.viaura_subtitles
        "Sort" -> R.drawable.viaura_sort
        "Refresh" -> R.drawable.viaura_refresh
        "SelectAll" -> R.drawable.viaura_checklist
        "Share" -> R.drawable.viaura_share
        "QueueMusic" -> R.drawable.viaura_audio_track
        "Replay" -> R.drawable.viaura_repeat
        "KeyboardArrowRight" -> R.drawable.viaura_arrow_right_solid
        "PhotoCamera" -> R.drawable.viaura_screenshot
        "CalendarToday" -> R.drawable.viaura_clock_circle
        "PlayCircle" -> R.drawable.viaura_play_circle
        "Loop" -> R.drawable.viaura_ab_loop
        "ColorLens" -> R.drawable.viaura_pallete_2
        "ContentCopy" -> R.drawable.viaura_copy
        "DriveFileMove" -> R.drawable.viaura_move_to_folder
        "Info" -> R.drawable.viaura_info_circle
        "AttachFile" -> R.drawable.viaura_document
        "Block" -> R.drawable.viaura_block
        "Bookmarks" -> R.drawable.viaura_bookmark
        "Cloud" -> R.drawable.viaura_cloud
        "FileDownload" -> R.drawable.viaura_download_minimalistic
        "FileUpload", "Upload" -> R.drawable.viaura_upload_minimalistic
        "FormatAlignCenter" -> R.drawable.viaura_align_horizontal_center
        "FormatBold" -> R.drawable.viaura_text_bold
        "FormatColorReset" -> R.drawable.viaura_eraser
        "FormatItalic" -> R.drawable.viaura_text_italic
        "HighQuality" -> R.drawable.viaura_high_quality
        "QueuePlayNext" -> R.drawable.viaura_playlist_video
        "Restore" -> R.drawable.viaura_restart
        "SettingsBackupRestore" -> R.drawable.viaura_settings_minimalistic
        "WatchLater" -> R.drawable.viaura_recent
        "Edit" -> R.drawable.viaura_pen
        "DriveFileRenameOutline" -> R.drawable.viaura_pen_2
        "Delete", "DeleteOutline" -> R.drawable.viaura_trash_bin_2
        "Send" -> R.drawable.viaura_share
        "OpenInNew" -> R.drawable.viaura_maximize_square
        "FolderShared" -> R.drawable.viaura_folder
        "MusicOff" -> R.drawable.viaura_volume_cross
        "NotificationsActive" -> R.drawable.viaura_notification_unread
        "PlaylistAdd" -> R.drawable.viaura_playlist_video
        "TextFields" -> R.drawable.viaura_text_field
        "Android" -> R.drawable.viaura_smartphone
        "AddFolder" -> R.drawable.viaura_add_folder
        "AccountTree" -> R.drawable.viaura_folder_with_files
        "Tv" -> R.drawable.viaura_video
        "Tune" -> R.drawable.viaura_tuning
        "Size" -> R.drawable.viaura_size
        "Payment" -> R.drawable.viaura_document
        "WarningAmber" -> R.drawable.viaura_shield_minimalistic
        "ErrorOutline" -> R.drawable.viaura_folder_error
        "Wifi" -> R.drawable.viaura_wifi
        "BatteryChargingFull", "BatteryStd" -> R.drawable.viaura_battery
        "RadioButtonUnchecked" -> R.drawable.viaura_minus_circle
        "ListCheck" -> R.drawable.viaura_checklist
        else -> 0
    }
    if (resId != 0) {
        Icon(painter = painterResource(resId), contentDescription = contentDescription, modifier = modifier, tint = tint)
    } else {
        Icon(imageVector = imageVector, contentDescription = contentDescription, modifier = modifier, tint = tint)
    }
}
