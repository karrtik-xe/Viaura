package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontFamily
import com.example.ui.theme.LocalAppFontFamily
import com.example.ui.theme.LocalIsSystemFontEnabled
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Animated "skip back / skip forward" icon: the ring spins one full turn with a bouncy spring
 * while the number in the middle shrinks and pops back.
 *
 * @param seconds Value shown inside the ring (2, 10, 20 ...).
 * @param forward true = skip forward, false = rewind.
 * @param trigger Increase by one to (re)play the animation. 0 shows the idle icon.
 * @param bounce  Spring damping ratio. Lower = more bounce.
 */
@Composable
fun SeekIcon(
    seconds: Int,
    forward: Boolean,
    trigger: Int,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    color: Color = Color.White,
    bounce: Float = 0.55f,
    stiffness: Float = 300f
) {
    val progress = remember { Animatable(1f) }

    LaunchedEffect(trigger) {
        if (trigger > 0) {
            progress.snapTo(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = bounce, stiffness = stiffness)
            )
        }
    }

    val p = progress.value
    val dir = if (forward) 1f else -1f
    val numberScale = 1f - 0.35f * sin(PI.toFloat() * p)
    val digitFactor = if (seconds > 99) 0.24f else 0.32f
    val fontSize = with(LocalDensity.current) { (size * digitFactor).toSp() }
    // System font ON -> the number uses the device font, otherwise the app font.
    val numberFont = if (LocalIsSystemFontEnabled.current) FontFamily.Default else LocalAppFontFamily.current

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(
            modifier = Modifier
                .size(size)
                .graphicsLayer { rotationZ = dir * 360f * p }
        ) {
            val shadowOffset = this.size.minDimension * 0.025f
            drawSeekGlyph(Color.Black.copy(alpha = 0.45f), forward, Offset(shadowOffset, shadowOffset))
            drawSeekGlyph(color, forward, Offset.Zero)
        }

        Text(
            text = seconds.toString(),
            color = color,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
            style = TextStyle(
                fontFamily = numberFont,
                shadow = Shadow(
                    color = Color.Black.copy(alpha = 0.55f),
                    offset = Offset(2f, 2f),
                    blurRadius = 4f
                )
            ),
            modifier = Modifier.graphicsLayer {
                scaleX = numberScale
                scaleY = numberScale
            }
        )
    }
}

private fun DrawScope.drawSeekGlyph(color: Color, forward: Boolean, shift: Offset) {
    val s = size.minDimension
    val c = Offset(s / 2f, s / 2f)
    val r = s * 0.38f
    val strokeStyle = Stroke(
        width = s * 0.075f,
        cap = StrokeCap.Round,
        join = StrokeJoin.Round
    )

    withTransform({
        translate(shift.x, shift.y)
        if (forward) scale(-1f, 1f, pivot = c)
    }) {
        val tipDeg = -100f
        drawArc(
            color = color,
            startAngle = tipDeg,
            sweepAngle = 315f,
            useCenter = false,
            topLeft = Offset(c.x - r, c.y - r),
            size = Size(r * 2f, r * 2f),
            style = strokeStyle
        )

        val a = Math.toRadians(tipDeg.toDouble())
        val tip = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
        val bx = -sin(a).toFloat()
        val by = cos(a).toFloat()
        val arm = s * 0.14f
        val k = Math.toRadians(40.0)

        fun armEnd(sign: Int): Offset {
            val ang = k * sign
            val rx = bx * cos(ang) - by * sin(ang)
            val ry = bx * sin(ang) + by * cos(ang)
            return Offset(tip.x + rx.toFloat() * arm, tip.y + ry.toFloat() * arm)
        }

        val head = Path().apply {
            val e1 = armEnd(1)
            val e2 = armEnd(-1)
            moveTo(e1.x, e1.y)
            lineTo(tip.x, tip.y)
            lineTo(e2.x, e2.y)
        }
        drawPath(head, color, style = strokeStyle)
    }
}
