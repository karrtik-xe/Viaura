package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.AccentGradientColors

/**
 * The app logo with the same sliding accent-gradient + moving shine as the Settings icon.
 * Used at the top-left of every screen header (video, audio, playlists, ...).
 */
@Composable
fun ShineLogoIcon(
    modifier: Modifier = Modifier,
    iconSize: Dp = 34.dp,
    contentDescription: String? = "Viaura Logo"
) {
    val transition = rememberInfiniteTransition(label = "logoIconShine")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logoIconGradientPhase"
    )
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "logoIconSweep"
    )
    val gradientColors = AccentGradientColors.let { it + it.first() }

    Icon(
        painter = painterResource(R.drawable.ic_abouticon),
        contentDescription = contentDescription,
        tint = Color.Black,
        modifier = modifier
            .size(iconSize)
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                val w = size.width
                val h = size.height
                // gradient only where the logo is drawn
                drawRect(
                    brush = Brush.linearGradient(
                        colors = gradientColors,
                        start = Offset(-w * phase, 0f),
                        end = Offset(w * (2f - phase), h)
                    ),
                    blendMode = BlendMode.SrcIn
                )
                // moving shine on top of the logo
                val bandX = -w + sweep * w * 3f
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.95f), Color.Transparent),
                        start = Offset(bandX, 0f),
                        end = Offset(bandX + w * 0.9f, h)
                    ),
                    blendMode = BlendMode.SrcAtop
                )
            }
    )
}
