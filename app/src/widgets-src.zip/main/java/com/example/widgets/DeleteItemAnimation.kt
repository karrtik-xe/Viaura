package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer

/**
 * Which list items (folder ids / video paths) are currently being deleted.
 * Phase 1 (`exiting = false`): the items pulse red while the files are removed.
 * Phase 2 (`exiting = true`): the items shrink, tilt and fade away before the list drops them.
 */
object DeleteAnimState {
    var keys: Set<String> by mutableStateOf(emptySet())
    var exiting: Boolean by mutableStateOf(false)

    fun start(newKeys: Set<String>) {
        exiting = false
        keys = newKeys
    }

    fun clear() {
        keys = emptySet()
        exiting = false
    }
}

private val DeleteRed = Color(0xFFEF4444)

/** Delete effect for one list / grid item. No-op (and no extra cost) while [active] is false. */
@Composable
fun Modifier.deleteAnimation(active: Boolean, exiting: Boolean): Modifier {
    if (!active) return this
    val exit by animateFloatAsState(
        targetValue = if (exiting) 1f else 0f,
        animationSpec = tween(durationMillis = 380, easing = FastOutSlowInEasing),
        label = "deleteExit"
    )
    val pulseTransition = rememberInfiniteTransition(label = "deletePulse")
    val pulse by pulseTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650, easing = LinearEasing), RepeatMode.Reverse),
        label = "deletePulseValue"
    )
    return this
        .graphicsLayer {
            val s = 1f - 0.45f * exit
            scaleX = s
            scaleY = s
            rotationZ = -5f * exit
            alpha = (1f - exit) * (0.78f + 0.22f * (1f - pulse))
            compositingStrategy = CompositingStrategy.Offscreen
        }
        .drawWithContent {
            drawContent()
            // red wash only where the card has pixels (keeps the rounded corners)
            drawRect(
                color = DeleteRed.copy(alpha = (0.10f + 0.12f * pulse) + 0.22f * exit),
                blendMode = BlendMode.SrcAtop
            )
        }
}

/** Wraps a folder / video card so it plays the delete animation when its [key] is being deleted. */
@Composable
fun DeleteAnimatedBox(
    key: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.deleteAnimation(key in DeleteAnimState.keys, DeleteAnimState.exiting)) {
        content()
    }
}
