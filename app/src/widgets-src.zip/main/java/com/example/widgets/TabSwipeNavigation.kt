package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sign

/**
 * Finger-follow horizontal swipe between the top level tabs (same idea as the Settings dashboard pager).
 * The page follows the finger with a soft resistance; on release it either snaps back, or - when dragged far
 * enough / flicked - slides out, the tab is switched, and the new page flows in from the opposite side with a
 * springy, liquid settle. Children that handle horizontal drags themselves (carousels, swipe rows) win first.
 */
fun Modifier.swipeBetweenTabs(
    enabled: Boolean,
    canGoNext: Boolean,
    canGoPrevious: Boolean,
    onNext: () -> Unit,
    onPrevious: () -> Unit
): Modifier = composed {
    val offset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var widthPx by remember { mutableFloatStateOf(1f) }
    val latestNext by rememberUpdatedState(onNext)
    val latestPrevious by rememberUpdatedState(onPrevious)
    val latestCanNext by rememberUpdatedState(canGoNext)
    val latestCanPrevious by rememberUpdatedState(canGoPrevious)

    this
        .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
        .pointerInput(enabled) {
            if (!enabled) return@pointerInput
            var total = 0f
            var startTime = 0L
            detectHorizontalDragGestures(
                onDragStart = {
                    total = 0f
                    startTime = System.currentTimeMillis()
                    scope.launch { offset.stop() }
                },
                onHorizontalDrag = { change, dragAmount ->
                    total += dragAmount
                    change.consume()
                    // Dragging right goes to the previous tab, left to the next one. Past the first / last tab the page
                    // only gives a tiny rubber-band pull.
                    val allowed = (total > 0f && latestCanPrevious) || (total < 0f && latestCanNext)
                    val factor = if (allowed) 0.6f else 0.12f
                    val target = (total * factor).coerceIn(-widthPx * 0.6f, widthPx * 0.6f)
                    scope.launch { offset.snapTo(target) }
                },
                onDragEnd = {
                    val elapsed = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
                    val distance = abs(total)
                    val isFlick = distance > widthPx * 0.08f && elapsed < 260L
                    val commit = distance > widthPx * 0.22f || isFlick
                    val goPrevious = total > 0f
                    val allowed = if (goPrevious) latestCanPrevious else latestCanNext
                    if (commit && allowed) {
                        val dir = sign(total)
                        scope.launch {
                            offset.animateTo(dir * widthPx * 0.45f, tween(130, easing = FastOutLinearInEasing))
                            if (goPrevious) latestPrevious() else latestNext()
                            // The new page enters from the opposite side and settles with a soft spring.
                            offset.snapTo(-dir * widthPx * 0.45f)
                            offset.animateTo(
                                0f,
                                spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow)
                            )
                        }
                    } else {
                        scope.launch {
                            offset.animateTo(0f, spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessMedium))
                        }
                    }
                    total = 0f
                },
                onDragCancel = {
                    total = 0f
                    scope.launch {
                        offset.animateTo(0f, spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessMedium))
                    }
                }
            )
        }
        .graphicsLayer {
            val fraction = (abs(offset.value) / widthPx).coerceIn(0f, 1f)
            translationX = offset.value
            alpha = 1f - fraction * 0.9f
            val s = 1f - fraction * 0.06f
            scaleX = s
            scaleY = s
        }
}
