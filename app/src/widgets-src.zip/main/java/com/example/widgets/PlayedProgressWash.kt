package com.example.ui.components

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AccentSkyBlue

/**
 * Played / watched progress shown as a soft colour wash over the WHOLE card (same look as the mini audio player):
 * the card is filled from the left edge up to the played fraction. Replaces the thin line that used to sit on the thumbnail.
 * Apply it to the card after its own background so the wash sits on top of the card colour and below the content.
 */
fun Modifier.playedProgressFill(
    progress: Float,
    isDark: Boolean,
    shape: Shape = RoundedCornerShape(16.dp)
): Modifier {
    val fraction = progress.coerceIn(0f, 1f)
    if (fraction <= 0f) return this
    val base = if (isDark) AccentSkyBlue.copy(alpha = 0.22f) else Color(0xFFBAE6FD).copy(alpha = 0.50f)
    val brush = Brush.horizontalGradient(listOf(base, base.copy(alpha = base.alpha * 1.25f)))
    return this
        .clip(shape)
        .drawBehind {
            drawRect(brush = brush, topLeft = Offset.Zero, size = Size(size.width * fraction, size.height))
        }
}
